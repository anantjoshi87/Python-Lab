import streamlit as st
import pandas as pd
import numpy as np
from utils.data_handler import DataHandler
from model.models import PerformancePredictor
from utils.smart_features import SmartFeatures
import os

# Page config
st.set_page_config(page_title="Student Performance Predictor", page_icon="🎓", layout="wide")

# -----------------------------
# Load & Train Model (Cached)
# -----------------------------
@st.cache_resource
def load_and_train():
    data_path = 'data/student_data.csv'
    
    if not os.path.exists(data_path):
        st.error("Dataset not found. Please run 'python data/generate_data.py' first.")
        st.stop()
        
    handler = DataHandler(data_path)
    X_train, X_test, y_score_train, y_score_test, y_pass_train, y_pass_test = handler.load_and_preprocess()
    
    predictor = PerformancePredictor()
    predictor.train(X_train, y_score_train, y_pass_train)
    
    return handler, predictor

handler, predictor = load_and_train()

# -----------------------------
# UI
# -----------------------------
st.title("🎓 Student Performance Prediction System")
st.markdown("Predict a student's final score and pass/fail status based on various features.")

# Sidebar Inputs
st.sidebar.header("Input Student Features")

st.sidebar.subheader("Core Features")
attendance = st.sidebar.slider("Attendance Percentage (%)", 0.0, 100.0, 80.0)
prev_gpa = st.sidebar.slider("Previous GPA (out of 10)", 0.0, 10.0, 7.5)
study_hours = st.sidebar.slider("Study Hours per Day", 0.0, 12.0, 4.0)
assignment_pct = st.sidebar.slider("Assignment Completion (%)", 0.0, 100.0, 85.0)
internal_marks = st.sidebar.slider("Internal Test Marks (%)", 0.0, 100.0, 70.0)

st.sidebar.subheader("Behavioral Features")
time_platforms = st.sidebar.slider("Time on Learning Platforms (hrs)", 0.0, 10.0, 2.0)
improvement_trend = st.sidebar.selectbox("Improvement Trend", ["Increasing", "Stable", "Decreasing"])
submission_time = st.sidebar.selectbox("Submission Timeliness", ["On-Time", "Late"])

st.sidebar.subheader("Personal & Academic Context")
study_env = st.sidebar.selectbox("Study Environment", ["Quiet", "Noisy"])
teacher_feedback = st.sidebar.slider("Teacher Feedback Score (1-10)", 1.0, 10.0, 7.0)

# Layout
col1, col2 = st.columns(2)

# -----------------------------
# Prediction Section
# -----------------------------
with col1:
    st.subheader("Predictive Analytics")
    
    if st.button("Predict Performance", type="primary"):
        
        input_data = {
            'Gender': 'Female',
            'Parent_Education': 'Bachelor',
            'Family_Income': 'Medium',
            'Study_Environment': study_env,
            'Location': 'Urban',
            'Attendance_Pct': attendance,
            'Prev_GPA': prev_gpa,
            'Assignment_Completion_Pct': assignment_pct,
            'Study_Hours_Per_Day': study_hours,
            'Class_Participation_Score': attendance * 0.8,
            'Internal_Test_Marks': internal_marks,
            'Submission_Timeliness': submission_time,
            'Time_On_Platforms_Hrs': time_platforms,
            'Video_Watch_Time_Hrs': time_platforms * 0.5,
            'Quiz_Trend': 'Flat',
            'Revision_Freq': 'Medium',
            'Improvement_Trend': improvement_trend,
            'Teacher_Feedback_Score': teacher_feedback,
            'Subject_Difficulty': 'Medium',
            'Practical_Performance': internal_marks,
            'Group_Study': 'Yes'
        }

        try:
            scaled_input = handler.preprocess_input(input_data)
            preds = predictor.predict(scaled_input)

            rf_score = float(preds['Predicted_Score_RF'][0])
            pass_status = int(preds['Pass_Fail_Prediction'][0])

            st.metric(label="Predicted Final Score", value=f"{rf_score:.2f} / 100")

            status_color = "green" if pass_status == 1 else "red"
            status_text = "PASS" if pass_status == 1 else "FAIL"

            st.markdown(
                f"**Predicted Status:** <span style='color:{status_color}; font-size: 24px; font-weight: bold;'>{status_text}</span>",
                unsafe_allow_html=True
            )

            # Smart Feedback
            st.subheader("💡 Smart Feedback & Insights")
            feedback_result = SmartFeatures.evaluate_student(input_data, rf_score, pass_status)

            if feedback_result['at_risk']:
                st.error("⚠️ Student is at risk.")
            else:
                st.success("✅ Student is on track.")

            for item in feedback_result['feedback']:
                st.info(item)

        except Exception as e:
            st.error(f"Prediction Error: {e}")

# -----------------------------
# Feature Importance Section
# -----------------------------
with col2:
    st.subheader("Model Insights")
    st.write("Top 5 Factors Influencing Prediction:")

    try:
        importances = predictor.get_feature_importances()
        feature_names = handler.feature_columns

        # Convert & clean
        importances = np.array(importances)
        importances = np.nan_to_num(importances, nan=0.0, posinf=0.0, neginf=0.0)

        # Match lengths safely
        min_len = min(len(importances), len(feature_names))
        importances = importances[:min_len]
        feature_names = feature_names[:min_len]

        df_imp = pd.DataFrame({
            'Feature': feature_names,
            'Importance': importances
        })

        # Remove invalid rows
        df_imp = df_imp[df_imp['Importance'] > 0]

        # Sort top 5
        df_imp = df_imp.sort_values('Importance', ascending=False).head(5)

        if df_imp.empty:
            st.warning("No valid feature importance data available.")
        else:
            st.bar_chart(df_imp.set_index('Feature'))

    except Exception as e:
        st.error(f"Feature Importance Error: {e}")