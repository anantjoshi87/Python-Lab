from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, accuracy_score, confusion_matrix
import numpy as np

class PerformancePredictor:
    def __init__(self):
        self.lin_reg = LinearRegression()
        self.rf_reg = RandomForestRegressor(n_estimators=100, random_state=42)
        self.log_reg = LogisticRegression(max_iter=1000, random_state=42)

    def train(self, X_train, y_score_train, y_pass_train):
        """Trains all models."""
        # Train regression models for score prediction
        self.lin_reg.fit(X_train, y_score_train)
        self.rf_reg.fit(X_train, y_score_train)
        
        # Train classification model for pass/fail prediction
        self.log_reg.fit(X_train, y_pass_train)
        
    def evaluate(self, X_test, y_score_test, y_pass_test):
        """Evaluates models and returns metrics."""
        metrics = {}
        
        # Linear Regression Eval
        lin_preds = self.lin_reg.predict(X_test)
        metrics['Linear_Regression'] = {
            'MAE': mean_absolute_error(y_score_test, lin_preds),
            'RMSE': np.sqrt(mean_squared_error(y_score_test, lin_preds))
        }
        
        # Random Forest Eval
        rf_preds = self.rf_reg.predict(X_test)
        metrics['Random_Forest'] = {
            'MAE': mean_absolute_error(y_score_test, rf_preds),
            'RMSE': np.sqrt(mean_squared_error(y_score_test, rf_preds))
        }
        
        # Logistic Regression Eval
        log_preds = self.log_reg.predict(X_test)
        metrics['Logistic_Regression'] = {
            'Accuracy': accuracy_score(y_pass_test, log_preds),
            'Confusion_Matrix': confusion_matrix(y_pass_test, log_preds)
        }
        
        return metrics

    def predict(self, X_input):
        """Predicts score and pass/fail for a single or multiple inputs."""
        return {
            'Predicted_Score_LR': self.lin_reg.predict(X_input),
            'Predicted_Score_RF': self.rf_reg.predict(X_input),
            'Pass_Fail_Prediction': self.log_reg.predict(X_input)
        }
        
    def get_feature_importances(self):
        """Returns feature importances from Random Forest."""
        return self.rf_reg.feature_importances_
