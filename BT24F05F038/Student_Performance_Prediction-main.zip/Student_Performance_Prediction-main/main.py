import argparse
from utils.data_handler import DataHandler
from model.models import PerformancePredictor
from utils.visualizer import Visualizer
from utils.smart_features import SmartFeatures
import json

def main():
    parser = argparse.ArgumentParser(description="Student Performance Prediction System")
    parser.add_argument('--data', type=str, default='data/student_data.csv', help='Path to dataset CSV')
    args = parser.parse_args()

    print("="*50)
    print("Student Performance Prediction System")
    print("="*50)

    # 1. Data Handling
    print("\n[1] Loading and preprocessing data...")
    handler = DataHandler(args.data)
    X_train, X_test, y_score_train, y_score_test, y_pass_train, y_pass_test = handler.load_and_preprocess()
    print(f"Data split into {len(X_train)} training and {len(X_test)} testing samples.")

    # 2. Modeling
    print("\n[2] Training Machine Learning Models...")
    predictor = PerformancePredictor()
    predictor.train(X_train, y_score_train, y_pass_train)
    print("Models trained successfully (Linear Regression, Random Forest, Logistic Regression).")

    # 3. Evaluation
    print("\n[3] Evaluating Models...")
    metrics = predictor.evaluate(X_test, y_score_test, y_pass_test)
    print(json.dumps(metrics, indent=2, default=str))

    # 4. Visualizations
    print("\n[4] Generating Visualizations...")
    viz = Visualizer(output_dir='output')
    
    # Feature Importance
    importances = predictor.get_feature_importances()
    feature_names = handler.feature_columns
    viz.plot_feature_importance(importances, feature_names, save=True)
    
    # Actual vs Predicted (Random Forest)
    rf_preds = predictor.rf_reg.predict(X_test)
    viz.plot_actual_vs_predicted(y_score_test, rf_preds, title='Random Forest: Actual vs Predicted', save=True)
    
    # Confusion Matrix (Logistic Regression)
    cm = metrics['Logistic_Regression']['Confusion_Matrix']
    viz.plot_confusion_matrix(cm, save=True)
    
    print("Visualizations saved in 'output' directory.")

    # 5. Make a sample prediction and use Smart Features
    print("\n[5] Sample Prediction & Smart Features...")
    sample_student = {
        'Gender': 'Female',
        'Parent_Education': 'Bachelor',
        'Family_Income': 'Medium',
        'Study_Environment': 'Noisy',
        'Location': 'Urban',
        'Attendance_Pct': 65.0,
        'Prev_GPA': 6.5,
        'Assignment_Completion_Pct': 70.0,
        'Study_Hours_Per_Day': 2.5,
        'Class_Participation_Score': 50.0,
        'Internal_Test_Marks': 60.0,
        'Submission_Timeliness': 'Late',
        'Time_On_Platforms_Hrs': 2.0,
        'Video_Watch_Time_Hrs': 1.0,
        'Quiz_Trend': 'Downward',
        'Revision_Freq': 'Low',
        'Improvement_Trend': 'Decreasing',
        'Teacher_Feedback_Score': 5.0,
        'Subject_Difficulty': 'Medium',
        'Practical_Performance': 65.0,
        'Group_Study': 'No'
    }
    
    # Preprocess
    scaled_input = handler.preprocess_input(sample_student)
    
    # Predict
    preds = predictor.predict(scaled_input)
    rf_score = preds['Predicted_Score_RF'][0]
    pass_status = preds['Pass_Fail_Prediction'][0]
    
    print("\nSample Student Data:")
    for k, v in sample_student.items():
        if k in ['Attendance_Pct', 'Study_Hours_Per_Day']:
            print(f"  {k}: {v}")
    
    print(f"\nPredicted Score (Random Forest): {rf_score:.2f}")
    print(f"Predicted Status: {'Pass' if pass_status == 1 else 'Fail'}")
    
    # Smart Features Feedback
    feedback_result = SmartFeatures.evaluate_student(sample_student, rf_score, pass_status)
    print("\nSmart Feedback:")
    for item in feedback_result['feedback']:
        print(f"  {item}")

    print("\n" + "="*50)
    print("Execution Completed Successfully.")
    print("="*50)

if __name__ == "__main__":
    main()
