import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder

class DataHandler:
    def __init__(self, filepath):
        self.filepath = filepath
        self.data = None
        self.X_train = None
        self.X_test = None
        self.y_score_train = None
        self.y_score_test = None
        self.y_pass_train = None
        self.y_pass_test = None
        self.scaler = StandardScaler()
        self.label_encoders = {}
        self.feature_columns = None

    def load_and_preprocess(self):
        """Loads data, handles missing values, encodes categories, and scales features."""
        # 1. Load Data
        self.data = pd.read_csv(self.filepath)
        
        # 2. Handle missing values (Fill numeric with mean, categorical with mode)
        for col in self.data.columns:
            if pd.api.types.is_numeric_dtype(self.data[col]):
                self.data[col] = self.data[col].fillna(self.data[col].mean())
            else:
                self.data[col] = self.data[col].fillna(self.data[col].mode()[0])
                
        # Separate features and targets
        X = self.data.drop(['Final_Score', 'Pass'], axis=1)
        y_score = self.data['Final_Score']
        y_pass = self.data['Pass']
        
        # 3. Encode categorical variables
        categorical_cols = X.select_dtypes(include=['object']).columns
        for col in categorical_cols:
            le = LabelEncoder()
            X[col] = le.fit_transform(X[col])
            self.label_encoders[col] = le
            
        self.feature_columns = X.columns
        
        # 4. Scale features
        X_scaled = self.scaler.fit_transform(X)
        X = pd.DataFrame(X_scaled, columns=self.feature_columns)
        
        # 5. Split Dataset
        self.X_train, self.X_test, self.y_score_train, self.y_score_test, self.y_pass_train, self.y_pass_test = train_test_split(
            X, y_score, y_pass, test_size=0.2, random_state=42
        )
        
        return self.X_train, self.X_test, self.y_score_train, self.y_score_test, self.y_pass_train, self.y_pass_test

    def preprocess_input(self, input_dict):
        """Preprocesses a single user input for prediction."""
        df = pd.DataFrame([input_dict])
        
        # Handle categorical
        for col, le in self.label_encoders.items():
            if col in df.columns:
                # Handle unseen labels by assigning a default or taking the first class (simplification for robustness)
                if df[col][0] not in le.classes_:
                    df[col][0] = le.classes_[0]
                df[col] = le.transform(df[col])
                
        # Ensure all columns exist
        for col in self.feature_columns:
            if col not in df.columns:
                df[col] = 0
                
        df = df[self.feature_columns] # Reorder to match training
        
        # Scale
        scaled_input = self.scaler.transform(df)
        return scaled_input
