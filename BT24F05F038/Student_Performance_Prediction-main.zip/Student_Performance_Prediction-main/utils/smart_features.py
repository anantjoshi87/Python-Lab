class SmartFeatures:
    @staticmethod
    def evaluate_student(student_data, predicted_score, pass_fail):
        """Generates an early warning and actionable feedback based on student data."""
        feedback = []
        is_at_risk = False
        
        if pass_fail == 0 or predicted_score < 50:
            is_at_risk = True
            feedback.append("EARLY WARNING: Student is at risk of failing.")
            
        # Analyze specific features to give targeted advice
        if student_data.get('Attendance_Pct', 100) < 75:
            feedback.append("- Improve attendance: Attendance is below 75%. Try to attend more classes.")
            
        if student_data.get('Study_Hours_Per_Day', 5) < 3:
            feedback.append("- Increase study hours: Studying less than 3 hours a day is impacting performance.")
            
        if student_data.get('Assignment_Completion_Pct', 100) < 80:
            feedback.append("- Complete assignments: A low assignment completion rate indicates missed practice.")
            
        if student_data.get('Submission_Timeliness', 'On-Time') == 'Late':
            feedback.append("- Timely submissions: Submitting assignments late negatively affects scores.")
            
        if student_data.get('Improvement_Trend', 'Stable') == 'Decreasing':
            feedback.append("- Reverse downward trend: Recent performance has been dropping. Seek help if needed.")
            
        if not feedback and is_at_risk:
            feedback.append("- General review: Review course materials and consult with the teacher.")
            
        if not is_at_risk and not feedback:
            feedback.append("On track! Keep up the good work.")
            
        return {
            "at_risk": is_at_risk,
            "feedback": feedback
        }
