import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import os

class Visualizer:
    def __init__(self, output_dir='output'):
        self.output_dir = output_dir
        os.makedirs(self.output_dir, exist_ok=True)
        
    def plot_feature_importance(self, importances, feature_names, save=False):
        """Plots a bar chart of feature importances."""
        df = pd.DataFrame({'Feature': feature_names, 'Importance': importances})
        df = df.sort_values('Importance', ascending=False).head(15) # Top 15 features
        
        plt.figure(figsize=(10, 6))
        sns.barplot(x='Importance', y='Feature', data=df, palette='viridis')
        plt.title('Top 15 Feature Importances (Random Forest)')
        plt.tight_layout()
        
        if save:
            path = os.path.join(self.output_dir, 'feature_importance.png')
            plt.savefig(path)
            print(f"Saved feature importance plot to {path}")
        else:
            plt.show()
            
    def plot_actual_vs_predicted(self, y_actual, y_pred, title='Actual vs Predicted Score', save=False):
        """Plots scatter plot of actual vs predicted scores."""
        plt.figure(figsize=(8, 6))
        plt.scatter(y_actual, y_pred, alpha=0.5, color='blue')
        plt.plot([y_actual.min(), y_actual.max()], [y_actual.min(), y_actual.max()], 'r--', lw=2)
        plt.xlabel('Actual Score')
        plt.ylabel('Predicted Score')
        plt.title(title)
        plt.tight_layout()
        
        if save:
            path = os.path.join(self.output_dir, 'actual_vs_predicted.png')
            plt.savefig(path)
            print(f"Saved plot to {path}")
        else:
            plt.show()

    def plot_confusion_matrix(self, cm, save=False):
        """Plots confusion matrix for classification."""
        plt.figure(figsize=(6, 4))
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=['Fail', 'Pass'], yticklabels=['Fail', 'Pass'])
        plt.xlabel('Predicted')
        plt.ylabel('Actual')
        plt.title('Confusion Matrix (Pass/Fail)')
        plt.tight_layout()
        
        if save:
            path = os.path.join(self.output_dir, 'confusion_matrix.png')
            plt.savefig(path)
            print(f"Saved confusion matrix plot to {path}")
        else:
            plt.show()
