import pandas as pd
import numpy as np
import os

def generate_synthetic_data(num_samples=1000, output_path='data/student_data.csv'):
    """Generates a synthetic dataset for student performance prediction."""
    
    np.random.seed(42)
    
    # 1. Personal Features
    gender = np.random.choice(['Male', 'Female', 'Other'], num_samples, p=[0.48, 0.48, 0.04])
    parent_education = np.random.choice(['High School', 'Bachelor', 'Master', 'PhD'], num_samples, p=[0.4, 0.4, 0.15, 0.05])
    family_income = np.random.choice(['Low', 'Medium', 'High'], num_samples, p=[0.3, 0.5, 0.2])
    study_environment = np.random.choice(['Quiet', 'Noisy'], num_samples, p=[0.7, 0.3])
    location = np.random.choice(['Urban', 'Rural'], num_samples, p=[0.6, 0.4])
    
    # 2. Core Features
    attendance_pct = np.clip(np.random.normal(80, 15, num_samples), 30, 100)
    prev_gpa = np.clip(np.random.normal(7.0, 1.5, num_samples), 2.0, 10.0)
    assignment_completion_rate = np.clip(np.random.normal(attendance_pct, 10, num_samples), 0, 100)
    study_hours_per_day = np.clip(np.random.normal(4, 2, num_samples), 0.5, 12)
    class_participation = np.clip(np.random.normal(attendance_pct/2, 10, num_samples), 0, 100)
    internal_test_marks = np.clip(np.random.normal(prev_gpa * 8, 15, num_samples), 0, 100)
    submission_timeliness = np.random.choice(['On-Time', 'Late'], num_samples, p=[0.8, 0.2])
    
    # 3. Behavioral Features
    time_on_platforms_hrs = np.clip(study_hours_per_day * np.random.uniform(0.5, 1.2, num_samples), 0, 10)
    video_watch_time_hrs = np.clip(time_on_platforms_hrs * np.random.uniform(0.4, 0.8, num_samples), 0, 8)
    quiz_trend = np.random.choice(['Upward', 'Flat', 'Downward'], num_samples, p=[0.4, 0.4, 0.2])
    revision_freq = np.random.choice(['High', 'Medium', 'Low'], num_samples, p=[0.3, 0.5, 0.2])
    improvement_trend = np.random.choice(['Increasing', 'Stable', 'Decreasing'], num_samples, p=[0.4, 0.4, 0.2])
    
    # 4. Academic Context Features
    teacher_feedback_score = np.clip(np.random.normal(attendance_pct/10, 1.5, num_samples), 1, 10)
    subject_difficulty = np.random.choice(['Easy', 'Medium', 'Hard'], num_samples, p=[0.2, 0.5, 0.3])
    practical_performance = np.clip(np.random.normal(internal_test_marks, 10, num_samples), 0, 100)
    group_study = np.random.choice(['Yes', 'No'], num_samples, p=[0.6, 0.4])
    
    # Generate Target Variable: Final Score based on a weighted combination of features
    # Add some noise
    base_score = (
        (attendance_pct * 0.2) +
        (prev_gpa * 8 * 0.2) +
        (assignment_completion_rate * 0.15) +
        (study_hours_per_day * 2 * 0.1) +
        (internal_test_marks * 0.2) +
        (practical_performance * 0.1)
    )
    
    # Adjust score based on qualitative factors
    score_adjustment = np.zeros(num_samples)
    score_adjustment += np.where(study_environment == 'Quiet', 3, -3)
    score_adjustment += np.where(submission_timeliness == 'On-Time', 2, -5)
    score_adjustment += np.where(improvement_trend == 'Increasing', 4, np.where(improvement_trend == 'Decreasing', -4, 0))
    score_adjustment += np.where(teacher_feedback_score > 7, 3, np.where(teacher_feedback_score < 4, -3, 0))
    
    final_score = np.clip(base_score + score_adjustment + np.random.normal(0, 5, num_samples), 0, 100)
    
    # Determine Pass/Fail (Pass if score >= 40)
    pass_fail = np.where(final_score >= 40, 1, 0) # 1 for Pass, 0 for Fail
    
    # Create DataFrame
    df = pd.DataFrame({
        'Gender': gender,
        'Parent_Education': parent_education,
        'Family_Income': family_income,
        'Study_Environment': study_environment,
        'Location': location,
        'Attendance_Pct': np.round(attendance_pct, 1),
        'Prev_GPA': np.round(prev_gpa, 2),
        'Assignment_Completion_Pct': np.round(assignment_completion_rate, 1),
        'Study_Hours_Per_Day': np.round(study_hours_per_day, 1),
        'Class_Participation_Score': np.round(class_participation, 1),
        'Internal_Test_Marks': np.round(internal_test_marks, 1),
        'Submission_Timeliness': submission_timeliness,
        'Time_On_Platforms_Hrs': np.round(time_on_platforms_hrs, 1),
        'Video_Watch_Time_Hrs': np.round(video_watch_time_hrs, 1),
        'Quiz_Trend': quiz_trend,
        'Revision_Freq': revision_freq,
        'Improvement_Trend': improvement_trend,
        'Teacher_Feedback_Score': np.round(teacher_feedback_score, 1),
        'Subject_Difficulty': subject_difficulty,
        'Practical_Performance': np.round(practical_performance, 1),
        'Group_Study': group_study,
        'Final_Score': np.round(final_score, 2),
        'Pass': pass_fail
    })
    
    # Ensure directory exists
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    
    # Save to CSV
    df.to_csv(output_path, index=False)
    print(f"Successfully generated {num_samples} samples at {output_path}")

if __name__ == '__main__':
    generate_synthetic_data()
